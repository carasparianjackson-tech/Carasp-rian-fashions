import React, { useEffect, useMemo, useState } from 'react';
import {
  ArrowRight, Search, ShoppingBag, Menu, X, MessageCircle, Instagram,
  Facebook, MapPin, Heart, SlidersHorizontal, Plus, Minus, Trash2,
  LayoutDashboard, Package, ClipboardList, Settings, LogOut, Pencil,
  Eye, EyeOff, ImagePlus, CheckCircle2, Clock3, ChevronDown, Store
} from 'lucide-react';
import { supabase, isConfigured } from './supabase';

const CATS = ["All", "Men's Fashion", "Women's Fashion", "Kids' Fashion", "Shoes", "Bags", "Accessories", "New Arrivals"];
const demoProducts = [
  {id:'demo-1',name:'Soft Blush Everyday Dress',category:"Women's Fashion",description:'A graceful everyday dress with a relaxed fit and a soft, comfortable feel.',sizes:['S','M','L','XL'],colours:['Blush','White','Plum'],available:true,image_url:'https://images.unsplash.com/photo-1539008835657-9e8e9680c956?w=900',featured:true},
  {id:'demo-2',name:'Classic Tailored Shirt',category:"Men's Fashion",description:'A clean, versatile shirt for smart and casual looks.',sizes:['S','M','L','XL'],colours:['White','Blue'],available:true,image_url:'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=900',featured:true},
  {id:'demo-3',name:'City Mini Shoulder Bag',category:'Bags',description:'A compact everyday bag with a timeless silhouette.',sizes:['One size'],colours:['Cream','Black','Pink'],available:true,image_url:'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=900',featured:true},
  {id:'demo-4',name:'Everyday Classic Sneakers',category:'Shoes',description:'Easy-to-style sneakers for everyday adventures.',sizes:['36','37','38','39','40','41'],colours:['White','Pink'],available:true,image_url:'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=900',featured:false},
  {id:'demo-5',name:'Little Explorer Set',category:"Kids' Fashion",description:'A playful and comfortable outfit for little ones.',sizes:['2-3Y','4-5Y','6-7Y'],colours:['Pink','Blue'],available:true,image_url:'https://images.unsplash.com/photo-1519238263530-99bdd11df2ea?w=900',featured:false},
  {id:'demo-6',name:'Rose Detail Earrings',category:'Accessories',description:'A delicate finishing touch for day or evening styling.',sizes:['One size'],colours:['Rose gold'],available:true,image_url:'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?w=900',featured:false}
];
const emptySettings = {store_name:'CARASPARIAN FASHION',tagline:'YOUR STYLE. YOUR CHOICE.',description:'Fashion that expresses you.',whatsapp:'',phone:'',email:'',location:'Kenya',delivery_info:'Contact us to confirm delivery options and charges.',instagram:'',facebook:'',logo_url:''};
const money = n => new Intl.NumberFormat('en-KE',{style:'currency',currency:'KES',maximumFractionDigits:0}).format(Number(n||0));
const makeOrderNo = () => 'CF-' + Date.now().toString().slice(-8);

function App(){
  const [page,setPage]=useState('home'), [products,setProducts]=useState(demoProducts), [settings,setSettings]=useState(emptySettings);
  const [category,setCategory]=useState('All'), [search,setSearch]=useState(''), [selected,setSelected]=useState(null);
  const [cart,setCart]=useState([]), [mobileMenu,setMobileMenu]=useState(false), [notice,setNotice]=useState('');
  const [session,setSession]=useState(null), [owner,setOwner]=useState(false), [orders,setOrders]=useState([]);
  const [privateData,setPrivateData]=useState({}), [loading,setLoading]=useState(false);
  const [adminTab,setAdminTab]=useState('Overview'), [showLogin,setShowLogin]=useState(false);
  const [orderForm,setOrderForm]=useState({full_name:'',phone:'',email:'',delivery_location:'',delivery_method:'To be discussed',instructions:''});
  const [orderDone,setOrderDone]=useState(null);

  useEffect(()=>{
    if(!isConfigured) return;
    let sub;
    (async()=>{
      const {data}=await supabase.auth.getSession(); setSession(data.session);
      sub=supabase.auth.onAuthStateChange((_e,s)=>setSession(s)).data.subscription;
      const {data:st}=await supabase.from('store_settings').select('*').eq('id',1).maybeSingle();
      if(st) setSettings({...emptySettings,...st});
    })();
    return ()=>sub?.unsubscribe();
  },[]);
  useEffect(()=>{ if(isConfigured) loadProducts(); },[]);
  useEffect(()=>{
    if(!session || !isConfigured){setOwner(false);return;}
    (async()=>{
      const {data}=await supabase.from('owner_profiles').select('user_id').eq('user_id',session.user.id).maybeSingle();
      setOwner(Boolean(data));
      if(data) loadPrivate();
    })();
  },[session]);
  const loadProducts=async()=>{
    const {data,error}=await supabase.from('products').select('*').order('created_at',{ascending:false});
    if(!error && data) setProducts(data);
  };
  const loadPrivate=async()=>{
    const [{data:p},{data:o}]=await Promise.all([
      supabase.from('product_private').select('*'),
      supabase.from('orders').select('*, order_items(*)').order('created_at',{ascending:false})
    ]);
    const map={}; (p||[]).forEach(x=>map[x.product_id]=x); setPrivateData(map); setOrders(o||[]);
  };
  const ping=(s)=>{setNotice(s);setTimeout(()=>setNotice(''),3500)};
  const filtered=useMemo(()=>products.filter(p=>(category==='All'||p.category===category||(category==='New Arrivals'&&p.is_new)) && (p.name||'').toLowerCase().includes(search.toLowerCase())),[products,category,search]);
  const addToCart=(p,variant)=>{
    setCart(old=>{const key=p.id+variant.size+variant.colour;const found=old.find(x=>x.key===key);return found?old.map(x=>x.key===key?{...x,quantity:x.quantity+variant.quantity}:x):[...old,{...variant,key,product:p}];});
    setSelected(null);ping('Added to your order');
  };
  const waLink=(message)=>{
    const digits=(settings.whatsapp||'').replace(/\D/g,'');
    if(!digits){ping('The shop WhatsApp number has not been configured yet.');return;}
    window.open(`https://wa.me/${digits}?text=${encodeURIComponent(message)}`,'_blank','noopener,noreferrer');
  };
  const orderMessage=(items=cart,form=orderForm)=>`Hello ${settings.store_name}, I would like to enquire about an order:\n${items.map(x=>`• ${x.product.name} | Size: ${x.size} | Colour: ${x.colour} | Qty: ${x.quantity}`).join('\n')}\nName: ${form.full_name||'Not provided'}\nPhone: ${form.phone||'Not provided'}\nDelivery location: ${form.delivery_location||'Not provided'}\nDelivery method: ${form.delivery_method||'To be discussed'}\nInstructions: ${form.instructions||'None'}\nPlease confirm the price and delivery arrangements.`;
  const submitOrder=async(e)=>{
    e.preventDefault();
    if(!cart.length) return ping('Add a product before submitting your order.');
    if(!/^\+?[\d\s()-]{9,16}$/.test(orderForm.phone)) return ping('Please enter a valid phone number.');
    if(!isConfigured) return ping('Connect the database before accepting live website orders.');
    setLoading(true);
    const order_no=makeOrderNo();
    const payload={order_no,...orderForm,status:'New order'};
    const {data,error}=await supabase.rpc('place_customer_order',{order_payload:payload,items_payload:cart.map(x=>({product_id:x.product.id,product_name:x.product.name,size:x.size,colour:x.colour,quantity:x.quantity}))});
    setLoading(false);
    if(error){ping(error.message);return;}
    setOrderDone(order_no);setCart([]);setPage('confirmation');
  };
  const login=async(e)=>{
    e.preventDefault(); const fd=new FormData(e.currentTarget);
    if(!isConfigured) return ping('Database setup is required before seller login.');
    const {error}=await supabase.auth.signInWithPassword({email:fd.get('email'),password:fd.get('password')});
    if(error) ping(error.message); else {setShowLogin(false);setPage('admin');}
  };
  const logout=async()=>{await supabase.auth.signOut();setPage('home');setOwner(false);};
  const saveProduct=async(e)=>{
    e.preventDefault();const fd=new FormData(e.currentTarget);const id=fd.get('id');
    let imageUrl=fd.get('image_url');
    const imageFile=fd.get('image_file');
    if(imageFile && imageFile.size){
      const safeName=imageFile.name.toLowerCase().replace(/[^a-z0-9.-]/g,'-');
      const path=`${crypto.randomUUID()}-${safeName}`;
      const {error:uploadError}=await supabase.storage.from('product-images').upload(path,imageFile,{upsert:false});
      if(uploadError)return ping('Image upload failed: '+uploadError.message);
      imageUrl=supabase.storage.from('product-images').getPublicUrl(path).data.publicUrl;
    }
    const product={name:fd.get('name'),category:fd.get('category'),description:fd.get('description'),sizes:String(fd.get('sizes')).split(',').map(x=>x.trim()).filter(Boolean),colours:String(fd.get('colours')).split(',').map(x=>x.trim()).filter(Boolean),image_url:imageUrl,available:fd.get('available')==='on',is_new:fd.get('is_new')==='on'};
    let pid=id;
    if(id){const {error}=await supabase.from('products').update(product).eq('id',id);if(error)return ping(error.message);}
    else {const {data,error}=await supabase.from('products').insert(product).select().single();if(error)return ping(error.message);pid=data.id;}
    const {error:pe}=await supabase.from('product_private').upsert({product_id:pid,price_kes:Number(fd.get('price')||0),stock_quantity:Number(fd.get('stock')||0)});
    if(pe)return ping(pe.message);
    await loadProducts();await loadPrivate();ping('Product saved successfully.');
  };
  const updateStatus=async(id,status)=>{
    const {error}=await supabase.from('orders').update({status}).eq('id',id);
    if(error)ping(error.message);else{await loadPrivate();ping('Order status updated.');}
  };
  const saveSettings=async(e)=>{
    e.preventDefault();const fd=new FormData(e.currentTarget);
    const next={...settings,store_name:fd.get('store_name'),tagline:fd.get('tagline'),description:fd.get('description'),whatsapp:fd.get('whatsapp'),phone:fd.get('phone'),email:fd.get('email'),location:fd.get('location'),delivery_info:fd.get('delivery_info'),instagram:fd.get('instagram'),facebook:fd.get('facebook')};
    const {error}=await supabase.from('store_settings').upsert({id:1,...next});
    if(error)ping(error.message);else{setSettings(next);ping('Store settings saved.');}
  };

  const ProductCard=({p})=><article className="product-card" onClick={()=>setSelected(p)}>
    <div className="product-image"><img src={p.image_url||'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=800'} alt={p.name}/>{(p.is_new||p.category==='New Arrivals')&&<span className="pill">NEW</span>}<button className="quick" aria-label="View product"><ArrowRight size={17}/></button></div>
    <div className="product-info"><small>{p.category}</small><h3>{p.name}</h3><p>{p.available===false?'Currently unavailable':'Contact us for price'}</p></div>
  </article>;

  return <div className="app">
    <div className="announcement">A LITTLE STYLE, A LOT OF CONFIDENCE · WELCOME TO CARASPARIAN</div>
    <header className="header">
      <button className="icon-btn mobile-only" onClick={()=>setMobileMenu(!mobileMenu)}>{mobileMenu?<X/>:<Menu/>}</button>
      <button className="brand" onClick={()=>{setPage('home');setCategory('All')}}><span className="brand-mark">C</span><span><b>CARASPARIAN</b><small>F A S H I O N</small></span></button>
      <nav className={mobileMenu?'nav open':'nav'}>{['Home','Shop','About','Contact'].map(n=><button key={n} onClick={()=>{setPage(n.toLowerCase());setMobileMenu(false)}}>{n}</button>)}</nav>
      <div className="header-actions"><button className="icon-btn" onClick={()=>setPage('shop')} aria-label="Search"><Search/></button><button className="bag-btn" onClick={()=>setPage('checkout')}><ShoppingBag size={19}/><span>{cart.reduce((a,x)=>a+x.quantity,0)}</span></button></div>
    </header>

    {page==='home'&&<><section className="hero"><div className="hero-copy"><span className="eyebrow">STYLE THAT SPEAKS</span><h1>Your style.<br/><em>Your choice.</em></h1><p>Find the pieces that feel like you. Discover fashion for every moment, every mood and every version of you.</p><button className="primary" onClick={()=>setPage('shop')}>EXPLORE COLLECTION <ArrowRight size={17}/></button><div className="hero-note">CURATED WITH LOVE · MADE FOR YOU</div></div><div className="hero-photo"><img src="https://images.unsplash.com/photo-1483985988355-763728e1935b?w=1200" alt="Fashion editorial"/></div><div className="hero-stamp">THE<br/>STYLE<br/>EDIT <span>✳</span></div></section>
      <section className="trust-row"><span>✧ Thoughtful style</span><span>✧ Easy ordering</span><span>✧ Personal service</span></section>
      <section className="section"><div className="section-heading"><div><span className="eyebrow">HANDPICKED FOR YOU</span><h2>Featured pieces</h2></div><button className="text-link" onClick={()=>setPage('shop')}>VIEW ALL <ArrowRight size={16}/></button></div><div className="product-grid">{products.filter(p=>p.featured||p.is_new).slice(0,4).map(p=><ProductCard key={p.id} p={p}/>)}</div></section>
      <section className="category-band"><div><span className="eyebrow">FIND YOUR LOOK</span><h2>Explore the collections</h2><p>Little details. Big statements. Your next favourite is waiting.</p></div><div className="category-chips">{CATS.slice(1).map(c=><button key={c} onClick={()=>{setCategory(c);setPage('shop')}}>{c}<ArrowRight size={15}/></button>)}</div></section>
      <section className="section"><div className="section-heading"><div><span className="eyebrow">JUST ARRIVED</span><h2>New arrivals</h2></div><button className="text-link" onClick={()=>{setCategory('New Arrivals');setPage('shop')}}>DISCOVER MORE <ArrowRight size={16}/></button></div><div className="product-grid">{products.filter(p=>p.is_new).slice(0,4).map(p=><ProductCard key={p.id} p={p}/>)}</div></section>
      <section className="contact-strip"><div><span className="eyebrow">LET'S MAKE IT PERSONAL</span><h2>Need a little help choosing?</h2><p>Talk to our team about sizes, colours, availability and delivery.</p></div><button className="light-btn" onClick={()=>waLink('Hello Carasparian Fashion, I would like some help choosing an item.')}>CHAT ON WHATSAPP <MessageCircle size={17}/></button></section>
    </>}
    {page==='shop'&&<section className="section shop-page"><span className="eyebrow">THE CARASPARIAN EDIT</span><h1 className="page-title">Shop the collection</h1><div className="shop-tools"><div className="searchbox"><Search size={18}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search fashion..."/></div><div className="category-scroll">{CATS.map(c=><button className={category===c?'active':''} key={c} onClick={()=>setCategory(c)}>{c}</button>)}</div></div><p className="results-count">{filtered.length} pieces to explore</p><div className="product-grid">{filtered.map(p=><ProductCard key={p.id} p={p}/>)}</div>{!filtered.length&&<div className="empty"><ShoppingBag size={30}/><h3>No pieces found</h3><p>Try another search or category.</p></div>}</section>}
    {page==='about'&&<section className="section info-page"><span className="eyebrow">OUR STORY</span><h1 className="page-title">Fashion should feel like you.</h1><p>{settings.description}</p><img className="about-image" src="https://images.unsplash.com/photo-1445205170230-053b83016050?w=1400" alt="Fashion collection"/></section>}
    {page==='contact'&&<section className="section info-page"><span className="eyebrow">WE'RE HERE TO HELP</span><h1 className="page-title">Let's talk style.</h1><p>Questions about a product, sizing or delivery? Get in touch with Carasparian Fashion.</p><div className="contact-cards"><div><MessageCircle/><h3>WhatsApp</h3><p>{settings.whatsapp||'Number to be added by the shop owner'}</p><button className="primary" onClick={()=>waLink('Hello Carasparian Fashion, I have an enquiry.')}>MESSAGE US</button></div><div><MapPin/><h3>Location</h3><p>{settings.location}</p></div><div><Store/><h3>Delivery</h3><p>{settings.delivery_info}</p></div></div></section>}
    {page==='checkout'&&<section className="section checkout-page"><span className="eyebrow">YOUR SELECTION</span><h1 className="page-title">Your order</h1>{!cart.length?<div className="empty"><ShoppingBag size={32}/><h3>Your order is waiting</h3><p>Explore the collection and add something you love.</p><button className="primary" onClick={()=>setPage('shop')}>SHOP NOW</button></div>:<div className="checkout-layout"><div className="cart-items">{cart.map(x=><div className="cart-item" key={x.key}><img src={x.product.image_url} alt=""/><div className="cart-desc"><b>{x.product.name}</b><small>Size: {x.size} · Colour: {x.colour}</small><small>Quantity: {x.quantity}</small><button className="remove" onClick={()=>setCart(cart.filter(y=>y.key!==x.key))}><Trash2 size={14}/> Remove</button></div></div>)}</div><form className="order-form" onSubmit={submitOrder}><h2>Delivery details</h2><p>Submit your request and our team will contact you to confirm pricing and delivery.</p><label>Full name<input required value={orderForm.full_name} onChange={e=>setOrderForm({...orderForm,full_name:e.target.value})}/></label><label>Phone number<input required placeholder="+254..." value={orderForm.phone} onChange={e=>setOrderForm({...orderForm,phone:e.target.value})}/></label><label>Email address (optional)<input type="email" value={orderForm.email} onChange={e=>setOrderForm({...orderForm,email:e.target.value})}/></label><label>Delivery location<input required value={orderForm.delivery_location} onChange={e=>setOrderForm({...orderForm,delivery_location:e.target.value})}/></label><label>Preferred delivery method<select value={orderForm.delivery_method} onChange={e=>setOrderForm({...orderForm,delivery_method:e.target.value})}><option>To be discussed</option><option>Pickup</option><option>Courier delivery</option><option>Local delivery</option></select></label><label>Additional instructions<textarea value={orderForm.instructions} onChange={e=>setOrderForm({...orderForm,instructions:e.target.value})}/></label><button className="primary full" disabled={loading}>{loading?'SUBMITTING...':'SUBMIT ORDER REQUEST'} <ArrowRight size={17}/></button><button type="button" className="whatsapp-btn full" onClick={()=>waLink(orderMessage())}><MessageCircle size={17}/> ORDER THROUGH WHATSAPP</button><small className="privacy-note">No payment is taken here. Your order is a request until the shop confirms price and delivery.</small></form></div>}</section>}
    {page==='confirmation'&&<section className="section confirmation"><CheckCircle2 size={55}/><span className="eyebrow">REQUEST RECEIVED</span><h1 className="page-title">Thank you for your order request.</h1><p>Your request has been sent to Carasparian Fashion. The shop will contact you to confirm the price and delivery arrangements.</p><div className="order-number">ORDER NUMBER <b>{orderDone}</b></div><button className="primary" onClick={()=>setPage('shop')}>CONTINUE SHOPPING</button></section>}

    {page==='admin'&&<section className="admin-shell">{!owner?<div className="admin-lock"><div className="lock-icon"><Store/></div><span className="eyebrow">PRIVATE SELLER AREA</span><h1>Seller dashboard</h1><p>Sign in with the shop owner's account to manage Carasparian Fashion.</p><button className="primary" onClick={()=>setShowLogin(true)}>SELLER LOGIN</button><button className="text-link" onClick={()=>setPage('home')}>Back to storefront</button></div>:<><aside className="admin-nav"><div className="admin-brand"><span className="brand-mark">C</span><b>SELLER SPACE</b></div>{[['Overview',LayoutDashboard],['Products',Package],['Orders',ClipboardList],['Store settings',Settings]].map(([n,I])=><button className={adminTab===n?'selected':''} key={n} onClick={()=>setAdminTab(n)}><I size={18}/>{n}</button>)}<button className="logout" onClick={logout}><LogOut size={18}/>Sign out</button></aside><div className="admin-content"><div className="admin-top"><div><span className="eyebrow">CARASPARIAN FASHION</span><h1>{adminTab}</h1></div><button className="outline-btn" onClick={()=>setPage('home')}>View storefront <Eye size={16}/></button></div>
      {adminTab==='Overview'&&<><div className="stat-grid">{[['Total products',products.length],['Available',products.filter(p=>p.available).length],['Out of stock',products.filter(p=>!p.available).length],['Total orders',orders.length],['New orders',orders.filter(o=>o.status==='New order').length],['Completed',orders.filter(o=>o.status==='Completed').length]].map(([n,v])=><div className="stat-card" key={n}><small>{n}</small><strong>{v}</strong></div>)}</div><div className="admin-panel"><h2>Recent orders</h2><OrderTable orders={orders.slice(0,5)} updateStatus={updateStatus} waLink={waLink}/></div></>}
      {adminTab==='Products'&&<ProductManager products={products} privateData={privateData} saveProduct={saveProduct} refresh={async()=>{await loadProducts();await loadPrivate()}} ping={ping}/>}
      {adminTab==='Orders'&&<div className="admin-panel"><h2>All customer orders</h2><OrderTable orders={orders} updateStatus={updateStatus} waLink={waLink}/></div>}
      {adminTab==='Store settings'&&<form className="admin-panel settings-form" onSubmit={saveSettings}><h2>Store information</h2><div className="form-grid">{[['store_name','Store name'],['tagline','Tagline'],['whatsapp','WhatsApp number (international format)'],['phone','Phone number'],['email','Email address'],['location','Location'],['instagram','Instagram URL'],['facebook','Facebook URL']].map(([n,l])=><label key={n}>{l}<input name={n} defaultValue={settings[n]}/></label>)}</div><label>Store description<textarea name="description" defaultValue={settings.description}/></label><label>Delivery information<textarea name="delivery_info" defaultValue={settings.delivery_info}/></label><button className="primary">SAVE SETTINGS</button><p className="privacy-note">Use your full international WhatsApp number, including country code, without spaces. Do not include the + sign.</p></form>}
      </div></>}</section>}

    <footer className="footer"><div className="footer-top"><div className="footer-brand"><span className="brand-mark">C</span><div><b>CARASPARIAN FASHION</b><small>YOUR STYLE. YOUR CHOICE.</small></div></div><p>Fashion that feels like you.</p><div className="socials">{settings.instagram&&<a href={settings.instagram} target="_blank" rel="noreferrer"><Instagram/></a>}{settings.facebook&&<a href={settings.facebook} target="_blank" rel="noreferrer"><Facebook/></a>}<button onClick={()=>waLink('Hello Carasparian Fashion!')}><MessageCircle/></button></div></div><div className="footer-bottom"><span>© {new Date().getFullYear()} Carasparian Fashion</span><span>Made for your style journey.</span><button onClick={()=>setPage('admin')}>Seller access</button></div></footer>
    <button className="floating-wa" aria-label="WhatsApp" onClick={()=>waLink('Hello Carasparian Fashion, I would like to make an enquiry.')}><MessageCircle/></button>

    {selected&&<ProductModal p={selected} close={()=>setSelected(null)} add={addToCart} waLink={waLink}/>}
    {showLogin&&<div className="modal-backdrop" onClick={()=>setShowLogin(false)}><form className="login-modal" onSubmit={login} onClick={e=>e.stopPropagation()}><button type="button" className="modal-close" onClick={()=>setShowLogin(false)}><X/></button><span className="eyebrow">OWNER ACCESS</span><h2>Welcome back.</h2><label>Email<input name="email" type="email" required/></label><label>Password<input name="password" type="password" required/></label><button className="primary full">SIGN IN SECURELY</button><small>Seller accounts are created and authorised through Supabase setup. There is no public seller registration.</small></form></div>}
    {notice&&<div className="toast">{notice}</div>}
    {!isConfigured&&<div className="setup-banner">Preview mode · Connect Supabase to enable live products, orders and seller login.</div>}
  </div>;
}

function ProductModal({p,close,add,waLink}){
 const [size,setSize]=useState(p.sizes?.[0]||'One size'),[colour,setColour]=useState(p.colours?.[0]||'Not specified'),[qty,setQty]=useState(1);
 return <div className="modal-backdrop" onClick={close}><div className="product-modal" onClick={e=>e.stopPropagation()}><button className="modal-close" onClick={close}><X/></button><img src={p.image_url} alt={p.name}/><div className="modal-details"><small>{p.category}</small><h2>{p.name}</h2><p>{p.description}</p><div className="variant-group"><b>Choose size</b><div className="variant-options">{(p.sizes||['One size']).map(s=><button className={size===s?'chosen':''} onClick={()=>setSize(s)} key={s}>{s}</button>)}</div></div><div className="variant-group"><b>Choose colour</b><div className="variant-options">{(p.colours||['Not specified']).map(c=><button className={colour===c?'chosen':''} onClick={()=>setColour(c)} key={c}>{c}</button>)}</div></div><div className="qty-row"><b>Quantity</b><div><button onClick={()=>setQty(Math.max(1,qty-1))}><Minus size={15}/></button>{qty}<button onClick={()=>setQty(qty+1)}><Plus size={15}/></button></div></div><p className="availability">{p.available===false?'Currently unavailable':'Availability and price confirmed by the shop'}</p><button className="primary full" disabled={p.available===false} onClick={()=>add(p,{size,colour,quantity:qty})}>ADD TO ORDER <ShoppingBag size={17}/></button><button className="whatsapp-btn full" onClick={()=>waLink(`Hello Carasparian Fashion, I am interested in ${p.name}. Size: ${size}. Colour: ${colour}. Quantity: ${qty}. Please confirm availability and price.`)}><MessageCircle size={17}/> ASK ON WHATSAPP</button></div></div></div>;
}
function OrderTable({orders,updateStatus,waLink}){
 const statuses=['New order','Pending confirmation','Confirmed','Processing','Ready for delivery','Completed','Cancelled'];
 if(!orders.length)return <div className="empty compact"><ClipboardList/><p>No orders received yet.</p></div>;
 return <div className="order-list">{orders.map(o=><div className="order-card" key={o.id}><div className="order-card-top"><b>{o.order_no}</b><small>{new Date(o.created_at).toLocaleString('en-KE')}</small></div><h3>{o.full_name}</h3><p>{o.phone} · {o.delivery_location}</p><div className="order-lines">{(o.order_items||[]).map(i=><span key={i.id}>{i.product_name} · {i.size} · {i.colour} × {i.quantity}</span>)}</div><div className="order-controls"><select value={o.status} onChange={e=>updateStatus(o.id,e.target.value)}>{statuses.map(s=><option key={s}>{s}</option>)}</select><button className="whatsapp-small" onClick={()=>waLink(`Hello ${o.full_name}, regarding your Carasparian Fashion order ${o.order_no}.`)}><MessageCircle size={15}/> Contact</button></div></div>)}</div>;
}
function ProductManager({products,privateData,saveProduct,refresh,ping}){
 const [editing,setEditing]=useState(null),[query,setQuery]=useState('');
 const list=products.filter(p=>p.name.toLowerCase().includes(query.toLowerCase()));
 const remove=async(id)=>{if(!confirm('Delete this product?'))return;const {error}=await supabase.from('products').delete().eq('id',id);if(error)ping(error.message);else{await refresh();ping('Product deleted.');}};
 return <div className="admin-panel"><div className="manager-head"><h2>Product catalogue</h2><button className="primary" onClick={()=>setEditing({})}><Plus size={17}/> ADD PRODUCT</button></div><input className="admin-search" placeholder="Search products..." value={query} onChange={e=>setQuery(e.target.value)}/>{editing!==null&&<form className="product-editor" onSubmit={async e=>{await saveProduct(e);setEditing(null)}}><h3>{editing.id?'Edit product':'Add a product'}</h3><input type="hidden" name="id" value={editing.id||''}/><div className="form-grid"><label>Product name<input name="name" required defaultValue={editing.name||''}/></label><label>Category<select name="category" defaultValue={editing.category||"Women's Fashion"}>{CATS.slice(1).map(c=><option key={c}>{c}</option>)}</select></label><label>Sizes (comma separated)<input name="sizes" defaultValue={(editing.sizes||[]).join(', ')}/></label><label>Colours (comma separated)<input name="colours" defaultValue={(editing.colours||[]).join(', ')}/></label><label>Private price (KES)<input name="price" type="number" min="0" step="1" defaultValue={privateData[editing.id]?.price_kes||''}/></label><label>Stock quantity<input name="stock" type="number" min="0" defaultValue={privateData[editing.id]?.stock_quantity||0}/></label><label>Product image URL<input name="image_url" type="url" defaultValue={editing.image_url||''}/></label><label>Upload photograph<input name="image_file" type="file" accept="image/*"/><small>Optional. Uploads to the product-images bucket.</small></label></div><label>Description<textarea name="description" required defaultValue={editing.description||''}/></label><div className="check-row"><label><input type="checkbox" name="available" defaultChecked={editing.available!==false}/> Available</label><label><input type="checkbox" name="is_new" defaultChecked={editing.is_new||false}/> New arrival</label></div><div className="editor-actions"><button className="primary">SAVE PRODUCT</button><button type="button" className="outline-btn" onClick={()=>setEditing(null)}>CANCEL</button></div></form>}<div className="managed-products">{list.map(p=><div className="managed-product" key={p.id}><img src={p.image_url} alt=""/><div><b>{p.name}</b><small>{p.category} · {p.available?'Available':'Unavailable'}</small><small>Private price: {money(privateData[p.id]?.price_kes)}</small></div><button className="icon-btn" onClick={()=>setEditing(p)}><Pencil size={17}/></button><button className="icon-btn danger" onClick={()=>remove(p.id)}><Trash2 size={17}/></button></div>)}</div></div>;
}
