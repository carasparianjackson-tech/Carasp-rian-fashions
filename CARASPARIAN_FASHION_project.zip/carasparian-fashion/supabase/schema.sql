-- CARASPARIAN FASHION — Supabase schema
-- Run in Supabase SQL Editor. Create the first owner account in Supabase Auth,
-- then insert that user's UUID into owner_profiles using the final statement below.

create extension if not exists pgcrypto;

create table if not exists public.owner_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null,
  description text not null default '',
  sizes text[] not null default '{}',
  colours text[] not null default '{}',
  image_url text,
  available boolean not null default true,
  is_new boolean not null default false,
  featured boolean not null default false,
  created_at timestamptz not null default now()
);

-- Private seller-only table. No public read policy is created.
create table if not exists public.product_private (
  product_id uuid primary key references public.products(id) on delete cascade,
  price_kes numeric(12,2) not null default 0 check (price_kes >= 0),
  stock_quantity integer not null default 0 check (stock_quantity >= 0),
  updated_at timestamptz not null default now()
);

create table if not exists public.store_settings (
  id integer primary key check (id = 1),
  store_name text not null default 'CARASPARIAN FASHION',
  tagline text not null default 'YOUR STYLE. YOUR CHOICE.',
  description text not null default 'Fashion that expresses you.',
  whatsapp text not null default '',
  phone text not null default '',
  email text not null default '',
  location text not null default 'Kenya',
  delivery_info text not null default 'Contact us to confirm delivery options and charges.',
  instagram text not null default '',
  facebook text not null default '',
  logo_url text not null default ''
);
insert into public.store_settings(id) values(1) on conflict(id) do nothing;

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_no text not null unique,
  full_name text not null,
  phone text not null,
  email text,
  delivery_location text not null,
  delivery_method text not null,
  instructions text,
  status text not null default 'New order'
    check(status in ('New order','Pending confirmation','Confirmed','Processing','Ready for delivery','Completed','Cancelled')),
  created_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  size text not null default '',
  colour text not null default '',
  quantity integer not null check(quantity between 1 and 100)
);

alter table public.owner_profiles enable row level security;
alter table public.products enable row level security;
alter table public.product_private enable row level security;
alter table public.store_settings enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;

-- An authenticated account can only read its own allow-list row.
create policy "Owner can read own profile" on public.owner_profiles
for select to authenticated using (auth.uid() = user_id);

-- Helper checks owner identity using a private allow-list table.
create or replace function public.is_store_owner()
returns boolean language sql stable security definer set search_path = public
as $$ select exists(select 1 from public.owner_profiles where user_id = auth.uid()); $$;
revoke all on function public.is_store_owner() from public;
grant execute on function public.is_store_owner() to authenticated;

-- Public catalogue only. Price/stock figures are never stored in this table.
create policy "Public can view available catalogue" on public.products
for select to anon, authenticated using (available = true or public.is_store_owner());
create policy "Owner manages products" on public.products
for all to authenticated using (public.is_store_owner()) with check (public.is_store_owner());

create policy "Owner manages private product data" on public.product_private
for all to authenticated using (public.is_store_owner()) with check (public.is_store_owner());

create policy "Public can read store contact settings" on public.store_settings
for select to anon, authenticated using (true);
create policy "Owner manages store settings" on public.store_settings
for all to authenticated using (public.is_store_owner()) with check (public.is_store_owner());

create policy "Owner reads orders" on public.orders
for select to authenticated using (public.is_store_owner());
create policy "Owner updates orders" on public.orders
for update to authenticated using (public.is_store_owner()) with check (public.is_store_owner());
create policy "Owner reads order items" on public.order_items
for select to authenticated using (public.is_store_owner());

-- Anonymous customers submit through this function only. It validates and writes
-- order + line items atomically; no anonymous SELECT policy exists for customer data.
create or replace function public.place_customer_order(order_payload jsonb, items_payload jsonb)
returns jsonb language plpgsql security definer set search_path = public
as $$
declare
  new_order_id uuid;
  clean_order_no text;
  item jsonb;
  item_count integer;
begin
  if jsonb_typeof(items_payload) <> 'array' then raise exception 'Invalid order items'; end if;
  item_count := jsonb_array_length(items_payload);
  if item_count < 1 or item_count > 20 then raise exception 'An order must contain 1 to 20 items'; end if;
  if length(trim(coalesce(order_payload->>'full_name',''))) < 2 then raise exception 'Enter your full name'; end if;
  if length(regexp_replace(coalesce(order_payload->>'phone',''), '[^0-9]', '', 'g')) not between 9 and 15 then raise exception 'Enter a valid phone number'; end if;
  if length(trim(coalesce(order_payload->>'delivery_location',''))) < 2 then raise exception 'Enter your delivery location'; end if;
  clean_order_no := 'CF-' || upper(substr(encode(gen_random_bytes(6),'hex'),1,10));

  insert into public.orders(order_no,full_name,phone,email,delivery_location,delivery_method,instructions,status)
  values(clean_order_no,trim(order_payload->>'full_name'),trim(order_payload->>'phone'),
    nullif(trim(order_payload->>'email'),''),trim(order_payload->>'delivery_location'),
    coalesce(nullif(trim(order_payload->>'delivery_method'),''),'To be discussed'),
    nullif(trim(order_payload->>'instructions'),''),'New order')
  returning id into new_order_id;

  for item in select * from jsonb_array_elements(items_payload) loop
    if coalesce((item->>'quantity')::integer,0) not between 1 and 100 then raise exception 'Invalid quantity'; end if;
    insert into public.order_items(order_id,product_id,product_name,size,colour,quantity)
    select new_order_id, p.id, p.name, coalesce(item->>'size',''), coalesce(item->>'colour',''), (item->>'quantity')::integer
    from public.products p
    where p.id = (item->>'product_id')::uuid and p.available = true;
    if not found then raise exception 'A selected product is unavailable'; end if;
  end loop;
  return jsonb_build_object('order_no',clean_order_no,'order_id',new_order_id);
end;
$$;
revoke all on function public.place_customer_order(jsonb,jsonb) from public;
grant execute on function public.place_customer_order(jsonb,jsonb) to anon, authenticated;

-- Product photos are public catalogue assets; only the allow-listed owner can manage them.
insert into storage.buckets (id, name, public)
values ('product-images', 'product-images', true)
on conflict (id) do update set public = true;

create policy "Public can view product images"
on storage.objects for select to anon, authenticated
using (bucket_id = 'product-images');

create policy "Owner can upload product images"
on storage.objects for insert to authenticated
with check (bucket_id = 'product-images' and public.is_store_owner());

create policy "Owner can update product images"
on storage.objects for update to authenticated
using (bucket_id = 'product-images' and public.is_store_owner())
with check (bucket_id = 'product-images' and public.is_store_owner());

create policy "Owner can delete product images"
on storage.objects for delete to authenticated
using (bucket_id = 'product-images' and public.is_store_owner());

-- Replace OWNER_USER_UUID below with the Auth user UUID after creating the owner.
-- insert into public.owner_profiles(user_id) values ('OWNER_USER_UUID');
