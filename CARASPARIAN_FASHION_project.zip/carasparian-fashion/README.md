# CARASPARIAN FASHION

Mobile-first fashion storefront and private seller dashboard starter.

## Included

- Pink / blush / plum responsive storefront
- Public product catalogue, categories and name search
- Product details with size, colour and quantity selection
- Website order requests and WhatsApp click-to-chat
- Private seller sign-in, overview, product CRUD, private KES prices and stock, order status management, store settings
- Supabase PostgreSQL schema with row-level security
- Customer order submission through a database function; no public read access to customer orders
- Public catalogue table deliberately contains no price column

## Important status

This is a deployable project source, not a live deployed shop. It starts in preview mode using sample products. Live multi-device data, seller login, permanent orders and product management require a Supabase project and configuration. The shop's real WhatsApp number must be entered in Store settings. No number or owner credentials are invented.

## 1. Set up Supabase (free tier availability and limits can change)

1. Create a Supabase project at https://supabase.com.
2. Open SQL Editor and run all of `supabase/schema.sql`.
3. In Authentication > Users, create the owner account using an email address and a strong unique password. Disable public signups in Authentication settings.
4. Copy the owner's user UUID. At the bottom of the SQL editor run:
   ```sql
   insert into public.owner_profiles(user_id)
   values ('PASTE-OWNER-USER-UUID-HERE');
   ```
5. In Storage, create a bucket named `product-images` and make it public. Product images are public catalogue assets; never upload customer documents or private data there.
6. Copy the Project URL and anon/public key from Project Settings > API.

## 2. Configure and run

1. Extract this ZIP.
2. Copy `.env.example` to `.env`.
3. Set:
   ```
   VITE_SUPABASE_URL=https://YOUR-PROJECT.supabase.co
   VITE_SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
   ```
   The anon key is intended for browser use; NEVER put a Supabase service-role key in this app.
4. Install Node.js on a computer or use a browser-based development workspace:
   ```
   npm install
   npm run dev
   ```
5. Run a production build:
   ```
   npm run build
   ```

## 3. Deploy

- Import the project into a private GitHub repository.
- Import that repository into Vercel.
- Add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` as Vercel environment variables.
- Deploy. Add the deployed domain to Supabase Auth URL configuration if needed.
- Test customer order submission and owner login after deployment.

Vercel and Supabase have had free tiers, but quotas, eligibility and terms can change. Confirm current pricing before launch. A custom domain, payment gateway, SMS or email notifications may cost extra; none are included or falsely represented as active.

## 4. Use from Android

You can open the deployed site in Chrome on Android. The storefront and seller dashboard use a responsive single-column/mobile navigation layout. For source edits, a browser IDE such as GitHub Codespaces or another Node-compatible workspace is more practical than editing source files directly on a phone. Keep account passwords private; never paste them into chat.

## 5. Product image workflow

In the seller dashboard, open Products and choose Add Product. You can paste an image URL or choose an image file; file uploads are stored in the `product-images` Supabase Storage bucket.

## Security notes

- No public seller registration is provided.
- Seller access requires a Supabase Auth account that is explicitly allow-listed in `owner_profiles`.
- RLS restricts private prices, stock, orders and customer details to the owner.
- Public products have no price field. Customer-facing components do not render private prices.
- Anonymous customers can submit orders only through the validated `place_customer_order` RPC; they cannot query orders or customer records.
- Review Supabase Auth rate limits, CAPTCHA/bot protection and database backups before public launch. Add CAPTCHA or edge rate-limiting before high-traffic production use.

## Known scope limitations to address before launch

- Product photographs can be uploaded from the seller product form to the public `product-images` Supabase Storage bucket, or supplied as an image URL.
- The settings screen supports store contact and social details; logo URL is reserved in schema but not yet editable in the UI.
- Sample products are local preview data only. They are replaced by database products after Supabase is configured.
- WhatsApp ordering opens the WhatsApp app/site with a prefilled message. The customer must press Send in WhatsApp.
- No online payment collection is included. Seller confirms price and delivery with the customer.
- This initial build is a single-store implementation. Multi-tenant marketplace isolation is not enabled.

## Before launch checklist

- [ ] Replace sample products with real products and photographs.
- [ ] Enter the real WhatsApp number and store contact information.
- [ ] Verify seller account allow-list and test sign-in.
- [ ] Test anonymous order submission from a second device.
- [ ] Verify the seller can see and update the order.
- [ ] Verify a signed-out visitor cannot read orders or private prices.
- [ ] Review privacy notice, delivery terms and Kenyan business requirements.
